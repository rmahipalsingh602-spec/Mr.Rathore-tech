const FEEDS = [
  {
    label: "GameSpot News",
    url: "https://www.gamespot.com/feeds/news/"
  },
  {
    label: "IGN All",
    url: "https://feeds.feedburner.com/ign/all"
  },
  {
    label: "Google News Launch Radar",
    url: buildGoogleNewsUrl('"mobile game" launch OR "worldwide launch" OR "out now" OR "soft launch"')
  },
  {
    label: "Google News Updates",
    url: buildGoogleNewsUrl('"mobile gaming update" OR "game patch" OR "new event" OR "season update"')
  },
  {
    label: "Google News Releases",
    url: buildGoogleNewsUrl('"available now on iOS" OR "available now on Android" OR "new game released"')
  }
];

exports.handler = async function handler() {
  const results = await Promise.allSettled(FEEDS.map(fetchFeed));
  const sourceNames = [];
  const collected = [];

  for (const result of results) {
    if (result.status !== "fulfilled") {
      continue;
    }

    if (result.value.items.length) {
      sourceNames.push(result.value.label);
      collected.push(...result.value.items);
    }
  }

  const items = dedupeAndSort(collected).slice(0, 18);
  const launches = items.filter((item) => item.category === "launch").slice(0, 6);
  const briefs = items.slice(0, 4).map(buildBrief);

  return {
    statusCode: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "public, max-age=300, stale-while-revalidate=1800"
    },
    body: JSON.stringify({
      updatedAt: new Date().toISOString(),
      sourceCount: sourceNames.length,
      sourceNames,
      items,
      launches,
      briefs
    })
  };
};

async function fetchFeed(feed) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8500);

  try {
    const response = await fetch(feed.url, {
      signal: controller.signal,
      headers: {
        "user-agent": "PocketGamerLiveFeed/1.0",
        accept: "application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.8"
      }
    });

    if (!response.ok) {
      throw new Error(`${feed.label} returned ${response.status}`);
    }

    const xml = await response.text();
    return {
      label: feed.label,
      items: parseRss(xml, feed.label)
    };
  } finally {
    clearTimeout(timeoutId);
  }
}

function parseRss(xml, fallbackSource) {
  const itemBlocks = xml.match(/<item\b[\s\S]*?<\/item>/gi) || [];

  return itemBlocks.map((block) => {
    const title = normalizeTitle(extractTag(block, ["title"]));
    const source = extractTag(block, ["source"]) || fallbackSource;
    const summary = compactSummary(
      extractTag(block, ["description", "content:encoded", "content"])
    );
    const publishedAt = normalizeDate(
      extractTag(block, ["pubDate", "published", "updated", "dc:date"])
    );
    const link = decodeEntities(extractTag(block, ["link"])) || "#";
    const image = extractImage(block);
    const category = classifyArticle(`${title} ${summary}`);
    const tags = extractTags(title, summary, category);

    return {
      title,
      source,
      summary,
      publishedAt,
      link,
      image,
      category,
      tags
    };
  }).filter((item) => item.title && item.link);
}

function extractTag(block, tags) {
  for (const tag of tags) {
    const escaped = escapeRegExp(tag);
    const match = block.match(new RegExp(`<${escaped}\\b[^>]*>([\\s\\S]*?)<\\/${escaped}>`, "i"));
    if (match) {
      return cleanXml(match[1]);
    }
  }

  return "";
}

function extractImage(block) {
  const mediaMatch = block.match(/<(?:media:content|media:thumbnail|enclosure)\b[^>]*url="([^"]+)"/i);
  if (mediaMatch) {
    return decodeEntities(mediaMatch[1]);
  }

  const description = extractTag(block, ["description", "content:encoded"]);
  const descriptionImage = description.match(/<img[^>]+src="([^"]+)"/i);
  if (descriptionImage) {
    return decodeEntities(descriptionImage[1]);
  }

  return "";
}

function normalizeTitle(value) {
  const clean = decodeEntities(stripHtml(value)).replace(/\s+/g, " ").trim();
  return clean.replace(/\s+-\s+[^-]+$/, "").trim();
}

function compactSummary(value) {
  const clean = decodeEntities(stripHtml(value)).replace(/\s+/g, " ").trim();
  if (!clean) {
    return "Fresh gaming story collected from the live feed.";
  }

  const short = clean.length > 220 ? `${clean.slice(0, 217).trim()}...` : clean;
  return short;
}

function normalizeDate(value) {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    return new Date().toISOString();
  }

  return parsed.toISOString();
}

function classifyArticle(text) {
  const value = text.toLowerCase();

  if (/(launch|released|release|available now|worldwide|global|soft launch|pre-register)/.test(value)) {
    return "launch";
  }

  if (/(update|patch|season|event|battle pass|expansion)/.test(value)) {
    return "update";
  }

  if (/(review|hands-on|preview)/.test(value)) {
    return "review";
  }

  if (/(tournament|championship|esports)/.test(value)) {
    return "event";
  }

  return "general";
}

function extractTags(title, summary, category) {
  const text = `${title} ${summary}`.toLowerCase();
  const tags = new Set([category]);

  if (text.includes("android")) tags.add("android");
  if (text.includes("ios") || text.includes("iphone") || text.includes("ipad")) tags.add("ios");
  if (text.includes("mobile")) tags.add("mobile");
  if (text.includes("multiplayer")) tags.add("multiplayer");
  if (text.includes("rpg")) tags.add("rpg");
  if (text.includes("strategy")) tags.add("strategy");
  if (text.includes("racing")) tags.add("racing");

  return Array.from(tags).slice(0, 3);
}

function buildBrief(item) {
  const label = item.category === "launch"
    ? "Launch radar"
    : item.category === "update"
      ? "Update watch"
      : "Live gaming brief";

  return {
    title: item.title,
    source: item.source,
    link: item.link,
    publishedAt: item.publishedAt,
    category: item.category,
    paragraphs: [
      `${label} picked up this story from ${item.source}.`,
      item.summary,
      "Use this as a fast brief on the homepage, then publish a unique full article if you want better long-term ranking for that topic."
    ]
  };
}

function dedupeAndSort(items) {
  const map = new Map();

  for (const item of items) {
    const key = `${item.title.toLowerCase()}|${item.source.toLowerCase()}`;
    const existing = map.get(key);

    if (!existing) {
      map.set(key, item);
      continue;
    }

    const currentTime = new Date(item.publishedAt).getTime();
    const existingTime = new Date(existing.publishedAt).getTime();
    if (currentTime > existingTime) {
      map.set(key, item);
    }
  }

  return Array.from(map.values()).sort((left, right) => {
    return new Date(right.publishedAt).getTime() - new Date(left.publishedAt).getTime();
  });
}

function buildGoogleNewsUrl(query) {
  return `https://news.google.com/rss/search?q=${encodeURIComponent(`${query} when:7d`)}&hl=en-US&gl=US&ceid=US:en`;
}

function cleanXml(value) {
  return value
    .replace(/^<!\[CDATA\[/, "")
    .replace(/\]\]>$/, "")
    .trim();
}

function stripHtml(value) {
  return value.replace(/<[^>]+>/g, " ");
}

function decodeEntities(value) {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
