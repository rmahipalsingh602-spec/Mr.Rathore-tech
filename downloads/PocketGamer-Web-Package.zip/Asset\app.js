const LIVE_ENDPOINT = "/.netlify/functions/gaming-news";

const samplePayload = {
  updatedAt: "2026-03-24T00:00:00.000Z",
  sourceCount: 0,
  sourceNames: ["Preview mode"],
  items: [
    {
      title: "Deploy on Netlify to activate the live gaming feed",
      link: "https://pocket-gamer.netlify.app/",
      source: "Pocket Gamer Setup",
      publishedAt: "2026-03-24T00:00:00.000Z",
      summary: "The homepage is ready to fetch real gaming news with a Netlify function. Local file previews show this fallback until the site runs on a web server.",
      category: "setup",
      image: "",
      tags: ["setup", "netlify", "live feed"]
    },
    {
      title: "AdSense code is active but live ads still require approval",
      link: "https://support.google.com/adsense/",
      source: "AdSense Readiness",
      publishedAt: "2026-03-24T00:00:00.000Z",
      summary: "Your publisher script is installed in the homepage head. Auto ads can start after Google finishes the review and Auto ads are enabled in the account.",
      category: "monetization",
      image: "",
      tags: ["adsense", "approval", "ads"]
    },
    {
      title: "Fresh content and original articles matter more than code for ranking",
      link: "https://developers.google.com/search/docs/fundamentals/seo-starter-guide",
      source: "SEO Readiness",
      publishedAt: "2026-03-24T00:00:00.000Z",
      summary: "The page now has technical SEO essentials, but top Google rankings depend on quality, originality, authority, internal links, and time.",
      category: "seo",
      image: "",
      tags: ["seo", "google", "ranking"]
    }
  ],
  launches: [],
  briefs: [
    {
      title: "How this auto brief system works",
      source: "Pocket Gamer Setup",
      link: "https://pocket-gamer.netlify.app/",
      publishedAt: "2026-03-24T00:00:00.000Z",
      category: "setup",
      paragraphs: [
        "The site uses a server-side feed function to collect live gaming headlines and latest release stories.",
        "Each story is turned into a fast summary card so the homepage can update daily without manually rewriting every item.",
        "For stronger SEO, use these briefs as a starting point and publish unique full articles on separate pages."
      ]
    }
  ]
};

const categoryLabels = {
  launch: "Launch Radar",
  update: "Update Watch",
  event: "Live Event",
  review: "Review Buzz",
  monetization: "AdSense",
  seo: "SEO",
  setup: "Setup",
  general: "Gaming News"
};

const state = {
  launchGrid: document.querySelector("[data-launch-grid]"),
  newsGrid: document.querySelector("[data-news-grid]"),
  briefGrid: document.querySelector("[data-brief-grid]"),
  statusCopy: document.querySelector("[data-status-copy]"),
  updatedTime: document.querySelector("[data-updated-time]"),
  feedHealth: document.querySelector("[data-feed-health]"),
  dynamicStructuredData: document.querySelector("#dynamic-structured-data")
};

document.addEventListener("DOMContentLoaded", () => {
  init().catch((error) => {
    console.error("Pocket Gamer boot error:", error);
    render(samplePayload, true);
  });
});

async function init() {
  if (window.location.protocol === "file:") {
    render(samplePayload, true);
    return;
  }

  try {
    const payload = await loadLiveFeed();
    render(payload, false);
  } catch (error) {
    console.error("Live feed unavailable:", error);
    render(samplePayload, true);
  }
}

async function loadLiveFeed() {
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 9000);

  try {
    const response = await fetch(LIVE_ENDPOINT, {
      signal: controller.signal,
      headers: {
        Accept: "application/json"
      }
    });

    if (!response.ok) {
      throw new Error(`Live feed error ${response.status}`);
    }

    const payload = await response.json();
    if (!payload || !Array.isArray(payload.items) || !payload.items.length) {
      throw new Error("Live feed returned no items");
    }

    return payload;
  } finally {
    window.clearTimeout(timeoutId);
  }
}

function render(payload, fallbackMode) {
  const launches = Array.isArray(payload.launches) && payload.launches.length
    ? payload.launches
    : payload.items.slice(0, 4);
  const newsItems = payload.items.slice(0, 9);
  const briefs = Array.isArray(payload.briefs) && payload.briefs.length
    ? payload.briefs
    : buildLocalBriefs(newsItems.slice(0, 3));

  state.statusCopy.textContent = fallbackMode
    ? "Fallback preview active. Deploy on Netlify for real daily news."
    : "Live feed connected and daily gaming news is active.";
  state.feedHealth.textContent = fallbackMode
    ? "Preview mode"
    : `${payload.sourceCount || 1} live source${payload.sourceCount === 1 ? "" : "s"} active`;
  state.updatedTime.textContent = formatDateTime(payload.updatedAt);

  state.launchGrid.innerHTML = launches.map((item) => renderNewsCard(item, true)).join("");
  state.newsGrid.innerHTML = newsItems.map((item) => renderNewsCard(item, false)).join("");
  state.briefGrid.innerHTML = briefs.map((item) => renderBriefCard(item)).join("");

  injectStructuredData(newsItems);
}

function renderNewsCard(item, launchMode) {
  const source = escapeHtml(item.source || "Live source");
  const title = escapeHtml(item.title || "Gaming update");
  const summary = escapeHtml(item.summary || "Fresh gaming update available now.");
  const category = escapeHtml(item.category || "general");
  const label = categoryLabels[item.category] || categoryLabels.general;
  const tags = Array.isArray(item.tags) ? item.tags.slice(0, 2) : [];
  const imageMarkup = item.image
    ? `<img src="${escapeAttribute(item.image)}" alt="${title}" loading="lazy" decoding="async" referrerpolicy="no-referrer">`
    : `
      <div class="cover-fallback ${category}">
        <span>${escapeHtml(label)}</span>
        <strong>${source}</strong>
      </div>
    `;

  return `
    <article class="news-card">
      <div class="media-frame">
        ${imageMarkup}
      </div>
      <div class="card-body">
        <div class="card-meta">
          <span class="chip">${source}</span>
          <span class="chip">${escapeHtml(relativeTime(item.publishedAt))}</span>
          ${launchMode ? `<span class="chip">Worldwide launch watch</span>` : ""}
          ${tags.map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join("")}
        </div>
        <h3>${title}</h3>
        <p>${summary}</p>
        <div class="card-actions">
          <a class="card-link" href="${escapeAttribute(item.link || "#")}" target="_blank" rel="noopener noreferrer">Read Source</a>
          <span class="outline-link">${escapeHtml(label)}</span>
        </div>
      </div>
    </article>
  `;
}

function renderBriefCard(item) {
  const paragraphs = Array.isArray(item.paragraphs) ? item.paragraphs : buildBriefParagraphs(item);
  const source = escapeHtml(item.source || "Live source");
  const title = escapeHtml(item.title || "Auto brief");

  return `
    <article class="brief-card">
      <div class="card-meta">
        <span class="chip">${source}</span>
        <span class="chip">${escapeHtml(relativeTime(item.publishedAt))}</span>
        <span class="chip">${escapeHtml(categoryLabels[item.category] || categoryLabels.general)}</span>
      </div>
      <h3>${title}</h3>
      <div class="brief-copy">
        ${paragraphs.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join("")}
      </div>
      <div class="card-actions">
        <a class="card-link" href="${escapeAttribute(item.link || "#")}" target="_blank" rel="noopener noreferrer">Open Original Source</a>
      </div>
    </article>
  `;
}

function buildLocalBriefs(items) {
  return items.map((item) => ({
    ...item,
    paragraphs: buildBriefParagraphs(item)
  }));
}

function buildBriefParagraphs(item) {
  const summary = item.summary || "This story is part of the latest gaming feed.";
  const source = item.source || "the source feed";
  const categoryText = categoryLabels[item.category] || categoryLabels.general;

  return [
    `${source} moved this story into the latest ${categoryText.toLowerCase()} flow for the homepage.`,
    summary,
    "Use this short brief as a fast summary, then expand it into a unique full article if you want stronger long-term Google ranking."
  ];
}

function injectStructuredData(items) {
  const itemList = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: items.slice(0, 10).map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      url: item.link,
      name: item.title
    }))
  };

  state.dynamicStructuredData.textContent = JSON.stringify(itemList);
}

function relativeTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "Fresh update";
  }

  const diffMs = date.getTime() - Date.now();
  const diffMinutes = Math.round(diffMs / 60000);
  const formatter = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  const thresholds = [
    { limit: 60, unit: "minute", value: diffMinutes },
    { limit: 24, unit: "hour", value: Math.round(diffMinutes / 60) },
    { limit: 30, unit: "day", value: Math.round(diffMinutes / 1440) }
  ];

  for (const threshold of thresholds) {
    if (Math.abs(threshold.value) < threshold.limit) {
      return formatter.format(threshold.value, threshold.unit);
    }
  }

  return formatDateTime(value);
}

function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "Awaiting update";
  }

  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit"
  }).format(date);
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replace(/`/g, "&#96;");
}
